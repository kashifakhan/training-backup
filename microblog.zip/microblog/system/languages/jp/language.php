<?php
	
	$current_language	= (object) array
	(
		'name'		=> 'Japanese',
		'php_timezone'	=> 'Asia/Tokyo',
		'php_locale'	=> 'ja_JP.UTF-8',
		
		'author_name'	=> 'Taku Nakajima',
		'author_url'	=> 'http://twitter.com/essa',
		
		'is_beta'		=> FALSE,
	);
	
?>
