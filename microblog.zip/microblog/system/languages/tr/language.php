<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Türkçe',
		'php_timezone'	=> 'Europe/Istanbul',
		'php_locale'	=> 'tr_TR.utf8',
		
		'author_name'	=> 'BattleNova',
		'author_url'	=> 'http://www.sharetronix.tk',
		
		'is_beta'		=> FALSE,
	)
	
?>