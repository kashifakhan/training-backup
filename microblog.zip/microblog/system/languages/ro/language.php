<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Română',
		'php_timezone'	=> 'Europe/Bucharest',
		'php_locale'	=> 'ro_RO.utf8',
		
		'author_name'	=> 'Stan Ionuț',
		'author_url'	=> 'http://ionut-stan.info',
		
		'is_beta'		=> FALSE,
	)
	
?>