<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Norwegian',
		'php_timezone'	=> 'Europe/Oslo',
		'php_locale'	=> 'nb_NO.utf8',
		
		'author_name'	=> 'Truls Paulsen',
		'author_url'	=> 'http://',
		
		'is_beta'		=> FALSE,
	)
	
?>