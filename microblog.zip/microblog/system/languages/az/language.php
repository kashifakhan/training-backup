<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Azəri',
		'php_timezone'	=> 'Asia/Tehran',
		'php_locale'	=> 'az_AZ.utf8',
		
		'author_name'	=> 'ibrahim jabbari',
		'author_url'	=> 'http://ibrahimjabbari.com',
		
		'is_beta'		=> FALSE,
	)
	
?>