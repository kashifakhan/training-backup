<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Lithuanian',
		'php_timezone'	=> 'Europe/Vilnius',
		'php_locale'	=> 'lt_LT.utf8',
		
		'author_name'	=> 'Aurimas',
		'author_url'	=> 'http://goon.lt',
		
		'is_beta'		=> FALSE,
	)
	
?>