<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Español (España)',
		'php_timezone'	=> 'Europe/Madrid',
		'php_locale'	=> 'es_ES.UTF-8',
		
		'author_name'	=> 'Marcos Besteiro López',
		'author_url'	=> 'http://propiedadprivada.com',
		
		'is_beta'		=> FALSE,
	)
	
?>