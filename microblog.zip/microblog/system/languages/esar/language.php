<?php
	
	$current_language	= (object) array
	(
		'name'		=> 'Spanish / Argentina',
		'php_timezone'	=> 'America/Santiago',
		'php_locale'	=> 'es_AR.utf8',
		
		'author_name'	=> 'Pablo Macaluso',
		'author_url'	=> 'http://twindo.la',
		
		'is_beta'		=> FALSE,
	);
	
?>