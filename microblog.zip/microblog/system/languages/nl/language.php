<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Nederlands',
		'php_timezone'	=> 'Europe/Amsterdam',
		'php_locale'	=> 'nl_NL.utf8',
		
		'author_name'	=> 'Swiggy',
		'author_url'	=> 'http://www.swiggy.eu',
		
		'is_beta'		=> FALSE,
	)
	
?>