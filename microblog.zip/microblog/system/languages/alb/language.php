<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Albanian',
		'php_timezone'	=> 'Europe/Tirane',
		'php_locale'	=> 'sq_AL.utf8',
		
		'author_name'	=> 'Mendim Idrizi',
		'author_url'	=> 'http://www.shqip.in',
		
		'is_beta'		=> FALSE,
	)
	
?>