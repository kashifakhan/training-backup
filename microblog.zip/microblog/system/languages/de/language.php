<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Deutsch',
		'php_timezone'	=> 'Europe/Berlin',
		'php_locale'	=> 'de_DE.utf8',
		
		'author_name'	=> 'Christoph Germscheid',
		'author_url'	=> 'http://www.ms-freunde.de',
		
		'is_beta'		=> FALSE,
	)
	
?>