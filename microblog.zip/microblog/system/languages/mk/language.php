<?php
	
	$current_language	= (object) array
	(
		'name'		=> 'Македонски',
		'php_timezone'	=> 'Europe/Skopje',
		'php_locale'	=> 'mk_MK.UTF-8',
		
		'author_name'	=> 'Ivan Mihajlovich',
		'author_url'	=> 'http://mikrobloger.com',
		 
		'is_beta'		=> FALSE,
	);
	
?>