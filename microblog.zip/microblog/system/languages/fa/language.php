<?php
	
	$current_language	= (object) array
	(
		'name'		=> 'Farsi',
		'php_timezone'	=> 'Asia/Tehran',
		'php_locale'	=> 'fa_IR.UTF-8',
		
		'author_name'	=> 'Amir Moghadam',
		'author_url'	=> 'http://www.friendfa.com',
		
		'is_beta'		=> FALSE,
	);
	
?>