<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Ukrainian',
		'php_timezone'	=> 'Europe/Kiev',
		'php_locale'	=> 'uk_UA.utf8',
		
		'author_name'	=> 'notbad',
		'author_url'	=> 'http://',
		
		'is_beta'		=> FALSE,
	)
	
?>