<?php
	
	$current_language	= (object) array
	(
		'name'		=> 'Portugues (Brazilian)',
		'php_timezone'	=> 'Europe/Lisbon',
		'php_locale'	=> 'pt_PT.UTF-8',
		
		'author_name'	=> 'Jeferson Jose Reis',
		'author_url'	=> 'http://amizzer.com',
		
		'is_beta'		=> FALSE,
	);
	
?>