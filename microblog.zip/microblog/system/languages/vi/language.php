<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Tiếng Việt',
		'php_timezone'	=> 'Asia/Ho_Chi_Minh',
		'php_locale'	=> 'vi_VN.utf8',
		
		'author_name'	=> 'Nguyen The Huy',
		'author_url'	=> 'http://codon.vmmo.net',
		
		'is_beta'		=> FALSE,
	)
	
?>