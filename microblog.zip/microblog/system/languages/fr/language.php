<?php
	
	$current_language	= (object) array
	(
		'name'		=> 'Francais',
		'php_timezone'	=> 'Europe/Paris',
		'php_locale'	=> 'fr_FR.UTF-8',
		
		'author_name'	=> 'Fabien Stoll',
		'author_url'	=> 'http://ecoloactu.com',
		
		'is_beta'		=> FALSE,
	);
	
?>