<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Portugues',
		'php_timezone'	=> 'Europe/Lisbon',
		'php_locale'	=> 'pt_PT.utf8',
		
		'author_name'	=> 'João Mesquita',
		'author_url'	=> 'http://treinador.es',
		
		'is_beta'		=> FALSE,
	)
	
?>