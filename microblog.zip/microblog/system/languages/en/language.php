<?php
	
	$current_language	= (object) array
	(
		'name'		=> 'English',
		'php_timezone'	=> 'America/New_York',
		'php_locale'	=> 'en_GB.UTF-8',
		
		'author_name'	=> 'Sharetronix',
		'author_url'	=> 'http://sharetronix.com',
		
		'is_beta'		=> FALSE,
	);
	
?>