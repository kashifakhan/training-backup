<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Galego',
		'php_timezone'	=> 'Europe/Madrid',
		'php_locale'	=> 'gl_ES.utf8',
		
		'author_name'	=> 'latrica',
		'author_url'	=> 'http://latri.ca',
		
		'is_beta'		=> FALSE,
	)
	
?>