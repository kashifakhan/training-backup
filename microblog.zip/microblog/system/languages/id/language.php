<?php
	
	$current_language	= (object) array
	(
		'name'		=> 'Indonesian',
		'php_timezone'	=> 'Asia/Jakarta',
		'php_locale'	=> 'id_ID.UTF-8',
		
		'author_name'	=> 'Cak-Ugik',
		'author_url'	=> 'http://laskarkopi.com',
		
		'is_beta'		=> FALSE,
	);
	
?>