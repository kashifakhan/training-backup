<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Croatian',
		'php_timezone'	=> 'Europe/Sarajevo',
		'php_locale'	=> 'hr_HR.utf8',
		
		'author_name'	=> 'Dario Abram',
		'author_url'	=> 'http://share.david-rose.co.cc/',
		
		'is_beta'		=> FALSE,
	)
	
?>