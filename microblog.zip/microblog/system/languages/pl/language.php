<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Polish',
		'php_timezone'	=> 'Europe/Warsaw',
		'php_locale'	=> 'pl_PL.utf8',
		
		'author_name'	=> 'Mariusz Bednarz',
		'author_url'	=> 'http://kalorie.net',
		
		'is_beta'		=> FALSE,
	)
	
?>