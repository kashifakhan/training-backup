<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Czech',
		'php_timezone'	=> 'Europe/Prague',
		'php_locale'	=> 'cs_CZ.utf8',
		
		'author_name'	=> 'Petr Bednar',
		'author_url'	=> 'http://twitter.com/PetrBednar',
		
		'is_beta'		=> FALSE,
	)
	
?>