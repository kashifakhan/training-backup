<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Armenian/Հայերեն',
		'php_timezone'	=> 'Asia/Yerevan',
		'php_locale'	=> 'hy_AM.utf8',
		
		'author_name'	=> 'Samvel Chakhalyan',
		'author_url'	=> 'http://myhayastan.am',
		
		'is_beta'		=> FALSE,
	)
	
?>