<?php
	
	$current_language	= (object) array
	(
		'name'		=> 'Russian',
		'php_timezone'	=> 'Europe/Moscow',
		'php_locale'	=> 'ru_RU.UTF-8',
		
		'author_name'	=> 'Elefant',
		'author_url'	=> 'http://micro.by',
		
		'is_beta'		=> FALSE,
	);
	
?>