<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Swedish',
		'php_timezone'	=> 'Europe/Stockholm',
		'php_locale'	=> 'sv_FI.utf8',
		
		'author_name'	=> 'Niclas',
		'author_url'	=> 'http://www.miniforum.se',
		
		'is_beta'		=> FALSE,
	)
	
?>