<?php
	
	$current_language	= (object) array
	(
		'name'		=> '简体中文',
		'php_timezone'	=> 'Asia/Hong_Kong',
		'php_locale'	=> 'zh_CN.UTF-8',
		
		'author_name'	=> 'Tim Kuo',
		'author_url'	=> 'http://xirang.us',
		
		'is_beta'		=> FALSE,
	);
	
?>