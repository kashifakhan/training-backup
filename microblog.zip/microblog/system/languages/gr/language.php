<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Greek',
		'php_timezone'	=> 'Europe/Athens',
		'php_locale'	=> 'el_GR.utf8',
		
		'author_name'	=> 'Karasardelis',
		'author_url'	=> 'http://www.tikiland.gr',
		
		'is_beta'		=> FALSE,
	)
	
?>