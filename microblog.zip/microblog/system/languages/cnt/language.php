<?php
	
	$current_language	= (object) array
	(
		'name'		=> '繁體中文',
		'php_timezone'	=> 'Asia/Taipei',
		'php_locale'	=> 'zh_TW.UTF-8',
		
		'author_name'	=> 'Tim Kuo',
		'author_url'	=> 'http://xirang.us',
		
		'is_beta'		=> FALSE,
	);
	
?>