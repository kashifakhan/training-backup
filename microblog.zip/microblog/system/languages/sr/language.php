<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Serbian',
		'php_timezone'	=> 'Europe/Belgrade',
		'php_locale'	=> 'sr_SR.utf8',
		
		'author_name'	=> 'Urosh',
		'author_url'	=> 'http://pratis.me/',
		
		'is_beta'		=> FALSE,
	)
	
?>