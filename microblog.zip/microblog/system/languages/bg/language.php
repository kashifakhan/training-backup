<?php
	
	$current_language = (object) array
	(
		'name'		=> 'Български',
		'php_timezone'	=> 'Europe/Sofia',
		'php_locale'	=> 'bg_BG.utf8',
		
		'author_name'	=> 'Nikola Pavlov',
		'author_url'	=> 'http://edno23.com',
		
		'is_beta'		=> FALSE,
	)
	
?>