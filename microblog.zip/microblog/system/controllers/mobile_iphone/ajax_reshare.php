<?php
	
	require_once($C->INCPATH.'controllers/ajax_reshare.php');
	
?>