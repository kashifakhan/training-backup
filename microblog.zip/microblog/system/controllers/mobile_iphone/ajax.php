<?php
	
	if( !$this->user->is_logged ) {
		return;
	}
	
	return;
	
?>