<?php
	
	require_once($C->INCPATH.'controllers/ajax_follow.php');
	
?>