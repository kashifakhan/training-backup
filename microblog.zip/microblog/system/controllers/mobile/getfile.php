<?php
	
	require_once($C->INCPATH.'controllers/getfile.php');
	
?>