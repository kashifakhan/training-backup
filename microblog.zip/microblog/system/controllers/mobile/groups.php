<?php
	
	if( !$this->network->id || !$this->user->is_logged ) {
		$this->redirect('home');
	}
	if( $this->network->id && $C->MOBI_DISABLED ) {
		$this->redirect('mobidisabled');
	}
	
	$this->load_langfile('mobile/global.php');
	$this->load_langfile('mobile/groups.php');
	
	$shows	= array('my', 'all');
	$D->show	= 'my';
	if( isset($_GET['show']) && in_array($_GET['show'],$shows) ) {
		$D->show	= $_GET['show'];
	}
	
	$D->page_title	= $this->lang('groups_page_title_'.$D->show, array('#SITE_TITLE#'=>$C->SITE_TITLE));
	
	$not_in_groups	= array();
	if( $this->user->info->is_network_admin == 0 ) {
		$not_in_groups 	= array_diff( $this->network->get_private_groups_ids(), $this->user->get_my_private_groups_ids() );
	}
	$not_in_groups	= count($not_in_groups)>0 ? ('AND id NOT IN('.implode(', ', $not_in_groups).')') : '';
	
	$D->num_results	= 0;
	$D->num_pages	= 0;
	$D->pg		= 1;
	$D->groups_html	= '';
	
	if( isset($_GET['pg']) ) {
		$D->pg	= intval($_GET['pg']);
		$D->pg	= max(1, $_GET['pg']);
	}
	
	$tmp	= array();
	if( $D->show == 'my' ) {
		$groups = $this->network->get_user_follows($this->user->id, FALSE, 'hisgroups')->follow_groups;
		$D->num_results	= count($groups);
		$D->num_pages	= ceil($D->num_results / $C->PAGING_NUM_GROUPS);
		$D->pg	= min($D->pg, $D->num_pages);
		$D->pg	= max($D->pg, 1);
		$from	= ($D->pg - 1) * $C->PAGING_NUM_GROUPS;
		$tmp	= array_keys(array_slice($groups, $from, $C->PAGING_NUM_GROUPS, TRUE));
		unset($groups);
	}
	else {
		$D->num_results	= $db2->fetch_field('SELECT COUNT(*) FROM groups WHERE 1 '.$not_in_groups);
		$D->num_pages	= ceil($D->num_results / $C->PAGING_NUM_GROUPS);
		$D->pg	= min($D->pg, $D->num_pages);
		$D->pg	= max($D->pg, 1);
		$from	= ($D->pg - 1) * $C->PAGING_NUM_GROUPS;
		$db2->query('SELECT id FROM groups WHERE 1 '.$not_in_groups.' ORDER BY title ASC, id ASC LIMIT '.$from.', '.$C->PAGING_NUM_GROUPS);
		while($o = $db2->fetch_object()) {
			$tmp[]	= $o->id;
		}
	}
	
	$g	= array();
	foreach($tmp as $sdf) {
		if($sdf = $this->network->get_group_by_id($sdf)) {
			$g[]	= $sdf;
		}
	}
	
	if( count($g) > 0 ) {
		ob_start();
		$i	= 0;
		foreach($g as $tmp) {
			$D->g	= $tmp;
			$D->g->list_index	= $i++;
			$this->load_template('mobile/single_group.php');
		}
		$D->groups_html	= ob_get_contents();
		ob_end_clean();
	}
	
	$this->load_template('mobile/groups.php');
	
?>