<?php
	
	require_once($C->INCPATH.'controllers/signout.php');
	
?>