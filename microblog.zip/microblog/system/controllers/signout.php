<?php
	
	$this->user->logout();
	$this->redirect('signin/signout:ok');
	
?>