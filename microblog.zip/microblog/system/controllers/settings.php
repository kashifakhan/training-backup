<?php
	
	$this->redirect('settings/profile');
	
?>