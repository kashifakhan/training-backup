<?php
	
	//This option is only available in Sharetronix Professional
	$this->redirect('dashboard');
	
?>