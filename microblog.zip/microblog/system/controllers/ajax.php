<?php
	
	if( !$this->network->id ) {
		return;
	}
	
	return;
	
?>