<?php

$header	= 
'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<title>'.SITE_TITLE.' - Installation</TITLE>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link href="../themes/default/css/inside.css" type="text/css" rel="stylesheet" />
	</head>
	<body>
		<div id="site">
			<div id="wholesite">
				<div id="toprow" class="specialhomelink">
					<div id="toprow2">
						<a id="logolink" title="'.SITE_TITLE.'"><strong>'.SITE_TITLE.'</strong></a>
					</div>
				</div>
				<div id="nethdr1">
					<div id="nethdr2">
						<div id="netnav" class="specialhomelink">
							<a class="onnettab homelink" style="cursor:default;"><span><b style="cursor:default;">'.$PAGE_TITLE.'</b></span></a>
						</div>
					</div>
				</div>
				<div style="padding-top:10px; padding-bottom:10px;">';
	
?>