<?php

$footer	= 
'
				</div>
			</div>
			<div id="footercorners"><div id="footercorners2"></div></div>
			<div id="subfooter">
				<div id="sfleft">
					Step '.$step.' of 8
				</div>
				<div id="sfright">
					<span style="color:#888;">
						Powered by
						<a href="http://sharetronix.com" target="_blank" style="color:#666;">Sharetronix</a> &middot; 
						<a href="http://blogtronixmicro.com" target="_blank" style="color:#666;">BlogtronixMicro</a> &middot; 
						<a href="http://blogtronix.com" target="_blank" style="color:#666;">Blogtronix</a>
					</span> 
				</div>
			</div>
		</div>
	</body>
</html>';

?>