<?php
	
	require_once('./system/LOADER.php');
	
?>