<?php
	
	$this->load_langfile('inside/footer.php');
	
?>
	</body>
</html>