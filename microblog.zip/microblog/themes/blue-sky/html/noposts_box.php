						<div class="noposts">
							<div class="nopoststop"><div class="nopoststop2"></div></div>
							<div class="nopostsbody">
								<h3><?= $D->noposts_box_title ?></h3>
								<p><?= $D->noposts_box_text ?></p>
							</div>
							<div class="nopostsbottom"><div class="nopostsbottom2"></div></div>
						</div>
